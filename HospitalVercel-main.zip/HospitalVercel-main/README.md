# Sitio institucional Hospital Pediátrico

Bla bla.

## Descripción

Descripción por acá

## Comenzando

### Dependencias

-   Express http://expressjs.com/

### Ejecutando el programa

-   Correr bla

## Desarrolladores

Lic. García Héctor  
:link: https://bla.com

## Versión

-   0.1
    -   Implementación inicial

## Licencia

MIT

## Conocimientos

Ejercitación propuesta para utilizar fortalecer manejo de matrices, arreglos unidimensionales y creación/modificación de colores RGB.
